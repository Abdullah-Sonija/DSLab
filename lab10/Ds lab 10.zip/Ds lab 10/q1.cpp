#include <iostream>
using namespace std;

class MinMaxHeap
{
public:
	int arr[66];
	int size;
	MinMaxHeap() { size = 0; }
	int parent(int i) { return (i-1)/2; }
	bool is_min_level(int i)
	{
		int level = 0;
		while(i>0)
		{
			i = parent(i);
			level++;
		}
		return (level%2 == 0);
	}
	void swap_vals(int &a,int &b) { int t = a; a = b; b = t; }
	void insert(int x)
	{
		arr[size] = x;
		bubble_up(size);
		size++;
	}
	void bubble_up(int i)
	{
		if(i == 0) return;
		bool minLevel = is_min_level(i);
		if(minLevel)
		{
			if(arr[i] > arr[parent(i)])
			{
				swap_vals(arr[i],arr[parent(i)]);
				bubble_up_max(parent(i));
			}
			else bubble_up_min(i);
		}
		else
		{
			if(arr[i] < arr[parent(i)])
			{
				swap_vals(arr[i],arr[parent(i)]);
				bubble_up_min(parent(i));
			}
			else bubble_up_max(i);
		}
	}
	void bubble_up_min(int i)
	{
		while(parent(parent(i)) >= 0 && arr[i] < arr[parent(parent(i))])
		{
			swap_vals(arr[i],arr[parent(parent(i))]);
			i = parent(parent(i));
		}
	}
	void bubble_up_max(int i)
	{
		while(parent(parent(i)) >= 0 && arr[i] > arr[parent(parent(i))])
		{
			swap_vals(arr[i],arr[parent(parent(i))]);
			i = parent(parent(i));
		}
	}
	void updateKey(int i,int new_val)
	{
		int old = arr[i];
		arr[i] = new_val;
		if(new_val > old)
		{
			if(is_min_level(i)) trickle_down_min(i);
			else trickle_down_max(i);
		}
		else if(new_val < old) bubble_up(i);
	}
	void deleteKey(int i)
	{
		arr[i] = arr[size-1];
		size--;
		if(is_min_level(i)) trickle_down_min(i);
		else trickle_down_max(i);
	}
	void trickle_down_min(int i)
	{
		int m = smallest_child_or_grandchild(i);
		if(m == -1) return;
		if(is_grandchild(i,m))
		{
			if(arr[m] < arr[i])
			{
				swap_vals(arr[m],arr[i]);
				int parent_m = parent(m);
				if(arr[m] > arr[parent_m]) swap_vals(arr[m],arr[parent_m]);
				trickle_down_min(m);
			}
		}
		else if(arr[m] < arr[i]) swap_vals(arr[m],arr[i]);
	}
	void trickle_down_max(int i)
	{
		int m = largest_child_or_grandchild(i);
		if(m == -1) return;
		if(is_grandchild(i,m))
		{
			if(arr[m] > arr[i])
			{
				swap_vals(arr[m],arr[i]);
				int parent_m = parent(m);
				if(arr[m] < arr[parent_m]) swap_vals(arr[m],arr[parent_m]);
				trickle_down_max(m);
			}
		}
		else if(arr[m] > arr[i]) swap_vals(arr[m],arr[i]);
	}
	bool is_grandchild(int p,int c) { return parent(c) != p; }
	int smallest_child_or_grandchild(int i)
	{
		int best = -1;
		for(int k = 1; k <= 4; k++)
		{
			int idx = 2*i + k;
			if(idx < size)
			{
				if(best == -1 || arr[idx] < arr[best]) best = idx;
			}
		}
		return best;
	}
	int largest_child_or_grandchild(int i)
	{
		int best = -1;
		for(int k = 1; k <= 4; k++)
		{
			int idx = 2*i + k;
			if(idx < size)
			{
				if(best == -1 || arr[idx] > arr[best]) best = idx;
			}
		}
		return best;
	}
	void display()
	{
		for(int i = 0; i < size; i++) cout<<arr[i]<<" ";
		cout<<endl;
	}
};

int main()
{
	MinMaxHeap h;
	h.insert(8);
	h.insert(7);
	h.insert(6);
	h.insert(5);
	h.insert(4);
	cout<<"Initial Heap: "; h.display();
	h.updateKey(2,1021);
	cout<<"After update_key(2,1021): "; h.display();
	h.deleteKey(1);
	cout<<"After delete_key(1): "; h.display();
	return 0;
}
