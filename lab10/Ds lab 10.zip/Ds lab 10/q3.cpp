#include <iostream>
using namespace std;

void heapify(int arr[], int n, int i)
{
	int largest = i;
	int left = 2*i + 1;
	int right = 2*i + 2;
	if(left < n && arr[left] > arr[largest]) largest = left;
	if(right < n && arr[right] > arr[largest]) largest = right;
	if(largest != i)
	{
		swap(arr[i], arr[largest]);
		heapify(arr, n, largest);
	}
}

int kthLargest(int arr[], int n, int k)
{
	for(int i = n/2 - 1; i >= 0; i--) heapify(arr, n, i);
	for(int i = n-1; i >= n-(k-1); i--)
	{
		swap(arr[0], arr[i]);
		heapify(arr, i, 0);
	}
	return arr[0];
}

int main()
{
	int arr1[] = {1, 23, 12, 9, 30, 2, 50};
	int n1 = 7;
	int k1 = 3;
	cout<<"Kth Largest: "<<kthLargest(arr1, n1, k1)<<endl;
	int arr2[] = {12, 3, 5, 7, 19};
	int n2 = 5;
	int k2 = 2;
	cout<<"Kth Largest: "<<kthLargest(arr2, n2, k2)<<endl;
	return 0;
}
